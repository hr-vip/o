# Bring the game window to the foreground so the D3D Present slot fires while
# the injector is probing. Unity stops presenting while the window is inactive.
$p = Get-Process 'ROB RUN' -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $p -or $p.MainWindowHandle -eq 0) { exit 1 }

Add-Type -Name Win -Namespace Native -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
'@

[Native.Win]::ShowWindow($p.MainWindowHandle, 9) | Out-Null
[Native.Win]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
exit 0
