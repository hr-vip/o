#Requires -RunAsAdministrator
# clean_eac.ps1 - remove the EasyAntiCheat_EOS install, service, cache and EOS
# account cache before a new account is used. The ban itself lives on the EOS
# account; this clears the machine side and the local caches.
$ErrorActionPreference = 'SilentlyContinue'

Write-Host '== processes =='
foreach ($n in @('ROB RUN', 'start_protected_game', 'EasyAntiCheat_EOS')) {
    Get-Process | Where-Object { $_.ProcessName -like "$n*" } | ForEach-Object {
        Write-Host ("kill  {0} ({1})" -f $_.ProcessName, $_.Id)
        Stop-Process -Id $_.Id -Force
    }
}

Write-Host '== services =='
Get-Service -Name 'EasyAntiCheat*' | ForEach-Object {
    Write-Host ("stop  {0}" -f $_.Name)
    Stop-Service -Name $_.Name -Force
    Write-Host ("delete {0}" -f $_.Name)
    sc.exe delete $_.Name | Out-Null
}

Write-Host '== directories =='
$dirs = @(
    (Join-Path ${env:ProgramFiles(x86)} 'EasyAntiCheat_EOS'),
    (Join-Path ${env:ProgramFiles(x86)} 'EasyAntiCheat'),
    (Join-Path $env:ProgramData 'EasyAntiCheat'),
    (Join-Path $env:LOCALAPPDATA 'EasyAntiCheat'),
    (Join-Path $env:APPDATA 'EasyAntiCheat'),
    (Join-Path $env:LOCALAPPDATA 'EpicOnlineServices'),
    (Join-Path $env:ProgramData 'EpicOnlineServices')
)
foreach ($d in $dirs) {
    if (Test-Path -LiteralPath $d) {
        Write-Host ("rm    {0}" -f $d)
        Remove-Item -LiteralPath $d -Recurse -Force
    }
}

Write-Host '== registry =='
$keys = @(
    'HKLM:\SOFTWARE\EasyAntiCheat',
    'HKLM:\SOFTWARE\WOW6432Node\EasyAntiCheat',
    'HKLM:\SOFTWARE\EpicGames\EasyAntiCheat',
    'HKLM:\SYSTEM\CurrentControlSet\Services\EasyAntiCheat',
    'HKLM:\SYSTEM\CurrentControlSet\Services\EasyAntiCheat_EOS'
)
foreach ($k in $keys) {
    if (Test-Path -LiteralPath $k) {
        Write-Host ("rm    {0}" -f $k)
        Remove-Item -LiteralPath $k -Recurse -Force
    }
}

Write-Host '== driver leftovers =='
Get-ChildItem -LiteralPath (Join-Path $env:SystemRoot 'System32\drivers') `
    -Filter 'EasyAntiCheat*.sys' -Force | ForEach-Object {
        Write-Host ("rm    {0}" -f $_.FullName)
        Remove-Item -LiteralPath $_.FullName -Force
    }

Write-Host '== temp =='
Get-ChildItem -LiteralPath $env:TEMP -Filter '*EasyAntiCheat*' -Force |
    Remove-Item -Recurse -Force
Get-ChildItem -LiteralPath $env:TEMP -Filter '*.dmp' -Force |
    Remove-Item -Force

Write-Host ''
Write-Host 'EAC_CLEAN_DONE - reboot before the next launch.'
