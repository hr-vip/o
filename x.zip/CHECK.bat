@echo off
setlocal EnableExtensions
title ROB RUN - PREFLIGHT CHECK
cd /d "%~dp0"

set "REPORT=%~dp0check-report.txt"
set "FAIL=0"

> "%REPORT%" echo ROB RUN KIT - PREFLIGHT REPORT
>>"%REPORT%" echo Date: %DATE% %TIME%
>>"%REPORT%" echo Computer: %COMPUTERNAME%
>>"%REPORT%" echo.
ver >>"%REPORT%" 2>&1
>>"%REPORT%" echo.

fltmc >nul 2>&1
if errorlevel 1 (
    >>"%REPORT%" echo [FAIL] Not running as administrator.
    set "FAIL=1"
) else (
    >>"%REPORT%" echo [OK]   Administrator.
)

for %%F in (
    "RobRunInternal.dll"
    "tools\orelia-mapper.exe"
    "tools\orelia-ioctl.sys"
    "tools\ioctl-injector.exe"
    "tools\msvcp140.dll"
    "tools\vcruntime140.dll"
    "tools\vcruntime140_1.dll"
    "banfix\clean_traces.ps1"
    "banfix\focus_game.ps1"
) do (
    if exist "%%~F" (
        for %%A in ("%%~F") do >>"%REPORT%" echo [OK]   %%~F  ^(%%~zA bytes^)
    ) else (
        >>"%REPORT%" echo [MISS] %%~F
        set "FAIL=1"
    )
)

tasklist /fi "IMAGENAME eq ROB RUN.exe" | findstr /i "ROB RUN.exe" >nul
if errorlevel 1 (
    >>"%REPORT%" echo [WARN] ROB RUN.exe is not running. Start the game first.
) else (
    >>"%REPORT%" echo [OK]   ROB RUN.exe is running.
)

powershell -NoProfile -Command "$p='HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity'; $v=(Get-ItemProperty -Path $p -Name Enabled -ErrorAction SilentlyContinue).Enabled; if ($v -eq 1) { '[WARN] Memory Integrity (HVCI) is ON - the mapper will fail. Turn it off and reboot.' } else { '[OK]   Memory Integrity (HVCI) off or absent.' }" >>"%REPORT%" 2>&1

powershell -NoProfile -Command "$p='HKLM:\SYSTEM\CurrentControlSet\Control\CI\Config'; $v=(Get-ItemProperty -Path $p -Name VulnerableDriverBlocklistEnable -ErrorAction SilentlyContinue).VulnerableDriverBlocklistEnable; if ($v -eq 1) { '[WARN] Microsoft Vulnerable Driver Blocklist is ON - turn it off and reboot.' } else { '[OK]   Vulnerable Driver Blocklist off or absent.' }" >>"%REPORT%" 2>&1

>>"%REPORT%" echo.
if "%FAIL%"=="1" (
    >>"%REPORT%" echo RESULT: FAIL - files or privileges are missing.
) else (
    >>"%REPORT%" echo RESULT: PASS - run INJECT.bat as administrator.
)

echo.
type "%REPORT%"
echo.
echo Report saved to %REPORT%
echo Press any key to close this window.
pause
exit /b %FAIL%
