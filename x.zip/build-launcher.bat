@echo off
cd /d "%~dp0"
set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" (
    echo [error] .NET Framework csc.exe not found.
    pause
    exit /b 1
)

"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ ^
    /reference:System.Web.Extensions.dll,System.Windows.Forms.dll,System.Drawing.dll ^
    /resource:RobRunInternal.dll,payload/RobRunInternal.dll ^
    /resource:tools\ioctl-injector.exe,payload/tools/ioctl-injector.exe ^
    /resource:tools\msvcp140.dll,payload/tools/msvcp140.dll ^
    /resource:tools\orelia-ioctl.sys,payload/tools/orelia-ioctl.sys ^
    /resource:tools\orelia-mapper.exe,payload/tools/orelia-mapper.exe ^
    /resource:tools\vcruntime140.dll,payload/tools/vcruntime140.dll ^
    /resource:tools\vcruntime140_1.dll,payload/tools/vcruntime140_1.dll ^
    /resource:banfix\clean_eac.ps1,payload/banfix/clean_eac.ps1 ^
    /resource:banfix\clean_traces.ps1,payload/banfix/clean_traces.ps1 ^
    /resource:banfix\focus_game.ps1,payload/banfix/focus_game.ps1 ^
    /resource:banfix\spoof\rrspoof.exe,payload/banfix/spoof/rrspoof.exe ^
    /resource:banfix\spoof\rrspoof.sys,payload/banfix/spoof/rrspoof.sys ^
    /out:RobRunLauncher.exe RobRunLauncher.cs

if errorlevel 1 (
    echo [error] Build failed.
    pause
    exit /b 1
)

echo [ok] Built standalone GUI RobRunLauncher.exe successfully.
pause
