using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

namespace RobRunLauncher
{
    internal static class Program
    {
        // ============================================================
        // 1. Replace these 3 values with your KeyAuth app details:
        //    https://keyauth.cc/app/
        // ============================================================
        internal static readonly string KeyAuthName = "YOUR_APP_NAME";
        internal static readonly string KeyAuthOwnerId = "YOUR_OWNER_ID";
        internal static readonly string KeyAuthVersion = "1.0";
        private const string KeyAuthEndpoint = "https://keyauth.win/api/1.3/";
        private const string ResourcePrefix = "payload/";

        internal static readonly string AppDataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "RobRunKit"
        );
        internal static readonly string RootDir = Path.Combine(AppDataDir, "runtime");
        internal static readonly string ToolsDir = Path.Combine(RootDir, "tools");
        internal static readonly string BanfixDir = Path.Combine(RootDir, "banfix");
        internal static readonly string DllPath = Path.Combine(RootDir, "RobRunInternal.dll");
        internal static readonly string LogPath = Path.Combine(RootDir, "inject-run.log");
        internal static readonly string ReportPath = Path.Combine(RootDir, "check-report.txt");
        internal static readonly string SavedKeyPath = Path.Combine(AppDataDir, "license.key");

        [STAThread]
        private static void Main()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LauncherForm());
        }

        internal static bool IsAdministrator()
        {
            var identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        internal static bool KeyAuthInit(out string sessionId, out string error)
        {
            sessionId = null;
            error = "Unknown error";

            var body = new Dictionary<string, string>
            {
                { "type", "init" },
                { "ver", KeyAuthVersion },
                { "name", KeyAuthName },
                { "ownerid", KeyAuthOwnerId }
            };

            Dictionary<string, object> resp;
            if (!PostForm(body, out resp, out error)) return false;

            bool ok = resp.ContainsKey("success") && Convert.ToBoolean(resp["success"]);
            if (!ok)
            {
                error = resp.ContainsKey("message") ? Convert.ToString(resp["message"]) : "Init failed";
                return false;
            }

            sessionId = resp.ContainsKey("sessionid") ? Convert.ToString(resp["sessionid"]) : string.Empty;
            return !string.IsNullOrEmpty(sessionId);
        }

        internal static bool KeyAuthLicense(string sessionId, string key, string hwid, out string error)
        {
            error = "Unknown error";

            var body = new Dictionary<string, string>
            {
                { "type", "license" },
                { "key", key },
                { "hwid", hwid },
                { "sessionid", sessionId },
                { "name", KeyAuthName },
                { "ownerid", KeyAuthOwnerId }
            };

            Dictionary<string, object> resp;
            if (!PostForm(body, out resp, out error)) return false;

            bool ok = resp.ContainsKey("success") && Convert.ToBoolean(resp["success"]);
            if (!ok)
            {
                error = resp.ContainsKey("message") ? Convert.ToString(resp["message"]) : "Invalid key";
                return false;
            }

            return true;
        }

        private static bool PostForm(
            Dictionary<string, string> fields,
            out Dictionary<string, object> parsed,
            out string error)
        {
            parsed = null;
            error = null;

            var sb = new StringBuilder();
            foreach (var kv in fields)
            {
                if (sb.Length > 0) sb.Append('&');
                sb.Append(Uri.EscapeDataString(kv.Key));
                sb.Append('=');
                sb.Append(Uri.EscapeDataString(kv.Value ?? string.Empty));
            }

            byte[] payload = Encoding.UTF8.GetBytes(sb.ToString());

            try
            {
                var req = (HttpWebRequest)WebRequest.Create(KeyAuthEndpoint);
                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";
                req.ContentLength = payload.Length;
                req.Timeout = 15000;

                using (var reqStream = req.GetRequestStream())
                {
                    reqStream.Write(payload, 0, payload.Length);
                }

                string raw;
                using (var resp = (HttpWebResponse)req.GetResponse())
                using (var reader = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                {
                    raw = reader.ReadToEnd();
                }

                var serializer = new JavaScriptSerializer();
                parsed = serializer.Deserialize<Dictionary<string, object>>(raw);
                if (parsed == null)
                {
                    error = "Empty response from KeyAuth.";
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        internal static bool ExtractEmbeddedPayload(out string error)
        {
            error = null;
            try
            {
                Assembly asm = Assembly.GetExecutingAssembly();
                string[] names = asm.GetManifestResourceNames();
                int extracted = 0;

                foreach (string resName in names)
                {
                    if (!resName.StartsWith(ResourcePrefix, StringComparison.Ordinal)) continue;

                    string relPath = resName.Substring(ResourcePrefix.Length).Replace('/', Path.DirectorySeparatorChar);
                    string outPath = Path.Combine(RootDir, relPath);
                    string outDir = Path.GetDirectoryName(outPath);
                    if (!Directory.Exists(outDir)) Directory.CreateDirectory(outDir);

                    using (Stream stream = asm.GetManifestResourceStream(resName))
                    {
                        if (stream == null) continue;
                        if (File.Exists(outPath) && new FileInfo(outPath).Length == stream.Length)
                        {
                            extracted++;
                            continue;
                        }

                        using (FileStream fs = File.Create(outPath))
                        {
                            stream.CopyTo(fs);
                        }
                        extracted++;
                    }
                }

                if (extracted == 0)
                {
                    error = "No embedded payload found. Rebuild with build-launcher.bat.";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        internal static string LoadSavedKey()
        {
            try
            {
                if (File.Exists(SavedKeyPath)) return File.ReadAllText(SavedKeyPath).Trim();
            }
            catch { }
            return string.Empty;
        }

        internal static void SaveKey(string key)
        {
            try
            {
                string dir = Path.GetDirectoryName(SavedKeyPath);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.WriteAllText(SavedKeyPath, key);
            }
            catch { }
        }

        internal static void TryDeleteSavedKey()
        {
            try
            {
                if (File.Exists(SavedKeyPath)) File.Delete(SavedKeyPath);
            }
            catch { }
        }

        internal static int ReadRegistryDword(string subKey, string valueName)
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(subKey))
                {
                    if (key == null) return 0;
                    object val = key.GetValue(valueName);
                    return val == null ? 0 : Convert.ToInt32(val);
                }
            }
            catch
            {
                return 0;
            }
        }
    }

    internal sealed class LauncherForm : Form
    {
        private static readonly Color BgDark = Color.FromArgb(15, 16, 23);
        private static readonly Color BgPanel = Color.FromArgb(24, 26, 37);
        private static readonly Color BgInput = Color.FromArgb(32, 35, 49);
        private static readonly Color BorderColor = Color.FromArgb(48, 52, 72);
        private static readonly Color AccentPrimary = Color.FromArgb(108, 92, 231);
        private static readonly Color AccentHover = Color.FromArgb(128, 114, 242);
        private static readonly Color AccentGreen = Color.FromArgb(0, 184, 148);
        private static readonly Color AccentOrange = Color.FromArgb(225, 112, 85);
        private static readonly Color TextPrimary = Color.FromArgb(238, 240, 248);
        private static readonly Color TextMuted = Color.FromArgb(148, 154, 178);

        private Point _dragOffset;
        private bool _dragging;
        private bool _busy;

        private Panel _loginPanel;
        private TextBox _keyBox;
        private Button _loginBtn;
        private Label _loginStatus;

        private Panel _mainPanel;
        private Button _btnInject;
        private Button _btnCheck;
        private Button _btnSpoof;
        private Button _btnClean;
        private RichTextBox _logBox;
        private Label _statusBadge;

        public LauncherForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(760, 500);
            BackColor = BgDark;
            DoubleBuffered = true;
            Text = "ROB RUN KIT";

            BuildTitleBar();
            BuildLoginPanel();
            BuildMainPanel();

            _mainPanel.Visible = false;
            _loginPanel.Visible = true;

            if (!Program.IsAdministrator())
            {
                _loginStatus.ForeColor = AccentOrange;
                _loginStatus.Text = "Run as Administrator! Right-click RobRunLauncher.exe -> Run as administrator.";
                _loginBtn.Enabled = false;
            }
            else if (Program.KeyAuthName == "YOUR_APP_NAME" || Program.KeyAuthOwnerId == "YOUR_OWNER_ID")
            {
                _loginStatus.ForeColor = AccentOrange;
                _loginStatus.Text = "KeyAuth not configured. Set KeyAuthName & KeyAuthOwnerId in RobRunLauncher.cs.";
                _loginBtn.Enabled = false;
            }
            else
            {
                string saved = Program.LoadSavedKey();
                if (!string.IsNullOrEmpty(saved))
                {
                    _keyBox.Text = saved;
                    _loginStatus.Text = "Saved key loaded. Click Activate to continue.";
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (var pen = new Pen(BorderColor, 1))
            {
                e.Graphics.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
            }
        }

        private void BuildTitleBar()
        {
            var bar = new Panel
            {
                Dock = DockStyle.Top,
                Height = 42,
                BackColor = BgPanel
            };
            bar.MouseDown += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    _dragging = true;
                    _dragOffset = new Point(e.X, e.Y);
                }
            };
            bar.MouseMove += (s, e) =>
            {
                if (_dragging)
                {
                    Point p = PointToScreen(e.Location);
                    Location = new Point(p.X - _dragOffset.X, p.Y - _dragOffset.Y);
                }
            };
            bar.MouseUp += (s, e) => _dragging = false;

            var accentStrip = new Panel
            {
                Dock = DockStyle.Left,
                Width = 4,
                BackColor = AccentPrimary
            };

            var title = new Label
            {
                Text = "ROB RUN KIT  //  LAUNCHER",
                ForeColor = TextPrimary,
                Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(16, 11)
            };

            var btnMin = CreateTitleButton("_", new Point(Width - 74, 6), (s, e) => WindowState = FormWindowState.Minimized);
            var btnClose = CreateTitleButton("X", new Point(Width - 38, 6), (s, e) => Close());

            bar.Controls.Add(accentStrip);
            bar.Controls.Add(title);
            bar.Controls.Add(btnMin);
            bar.Controls.Add(btnClose);
            Controls.Add(bar);
        }

        private Button CreateTitleButton(string text, Point loc, EventHandler onClick)
        {
            var btn = new Button
            {
                Text = text,
                Location = loc,
                Size = new Size(30, 30),
                FlatStyle = FlatStyle.Flat,
                BackColor = BgPanel,
                ForeColor = TextMuted,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                TabStop = false
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = BgInput;
            btn.Click += onClick;
            return btn;
        }

        private void BuildLoginPanel()
        {
            _loginPanel = new Panel
            {
                Location = new Point(0, 42),
                Size = new Size(Width, Height - 42),
                BackColor = BgDark
            };

            var card = new Panel
            {
                Location = new Point(180, 95),
                Size = new Size(400, 250),
                BackColor = BgPanel
            };
            card.Paint += (s, e) =>
            {
                using (var pen = new Pen(BorderColor, 1))
                {
                    e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
                }
            };

            var heading = new Label
            {
                Text = "LICENSE AUTHENTICATION",
                ForeColor = TextPrimary,
                Font = new Font("Segoe UI Semibold", 13f, FontStyle.Bold),
                Location = new Point(28, 26),
                AutoSize = true
            };

            var sub = new Label
            {
                Text = "Enter your KeyAuth license key to unlock the kit.",
                ForeColor = TextMuted,
                Font = new Font("Segoe UI", 9f),
                Location = new Point(28, 56),
                AutoSize = true
            };

            _keyBox = new TextBox
            {
                Location = new Point(28, 95),
                Size = new Size(344, 32),
                BackColor = BgInput,
                ForeColor = TextPrimary,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 11f)
            };

            _loginBtn = CreateActionButton("ACTIVATE & CONTINUE", AccentPrimary, new Point(28, 142), new Size(344, 42));
            _loginBtn.Click += (s, e) => StartAuth();

            _loginStatus = new Label
            {
                Text = "Ready.",
                ForeColor = TextMuted,
                Font = new Font("Segoe UI", 8.5f),
                Location = new Point(28, 198),
                Size = new Size(344, 36)
            };

            card.Controls.Add(heading);
            card.Controls.Add(sub);
            card.Controls.Add(_keyBox);
            card.Controls.Add(_loginBtn);
            card.Controls.Add(_loginStatus);
            _loginPanel.Controls.Add(card);
            Controls.Add(_loginPanel);
        }

        private void BuildMainPanel()
        {
            _mainPanel = new Panel
            {
                Location = new Point(0, 42),
                Size = new Size(Width, Height - 42),
                BackColor = BgDark
            };

            var sidebar = new Panel
            {
                Location = new Point(16, 16),
                Size = new Size(210, Height - 74),
                BackColor = BgPanel
            };
            sidebar.Paint += (s, e) =>
            {
                using (var pen = new Pen(BorderColor, 1))
                {
                    e.Graphics.DrawRectangle(pen, 0, 0, sidebar.Width - 1, sidebar.Height - 1);
                }
            };

            var menuLabel = new Label
            {
                Text = "MODULES",
                ForeColor = TextMuted,
                Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold),
                Location = new Point(16, 14),
                AutoSize = true
            };

            _btnInject = CreateActionButton("INJECT", AccentPrimary, new Point(14, 42), new Size(182, 46));
            _btnCheck = CreateActionButton("PREFLIGHT CHECK", BgInput, new Point(14, 98), new Size(182, 42));
            _btnSpoof = CreateActionButton("HWID SPOOF", BgInput, new Point(14, 150), new Size(182, 42));
            _btnClean = CreateActionButton("CLEAN TRACES", BgInput, new Point(14, 202), new Size(182, 42));

            _btnInject.Click += (s, e) => RunTask("INJECT", RunInjection);
            _btnCheck.Click += (s, e) => RunTask("PREFLIGHT", RunPreflightCheck);
            _btnSpoof.Click += (s, e) => RunTask("SPOOF", RunSpoof);
            _btnClean.Click += (s, e) => RunTask("CLEAN", RunClean);

            _statusBadge = new Label
            {
                Text = "● LICENSE ACTIVE",
                ForeColor = AccentGreen,
                Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold),
                Location = new Point(16, sidebar.Height - 34),
                AutoSize = true
            };

            sidebar.Controls.Add(menuLabel);
            sidebar.Controls.Add(_btnInject);
            sidebar.Controls.Add(_btnCheck);
            sidebar.Controls.Add(_btnSpoof);
            sidebar.Controls.Add(_btnClean);
            sidebar.Controls.Add(_statusBadge);

            var logContainer = new Panel
            {
                Location = new Point(240, 16),
                Size = new Size(Width - 256, Height - 74),
                BackColor = BgPanel
            };
            logContainer.Paint += (s, e) =>
            {
                using (var pen = new Pen(BorderColor, 1))
                {
                    e.Graphics.DrawRectangle(pen, 0, 0, logContainer.Width - 1, logContainer.Height - 1);
                }
            };

            var logHeader = new Label
            {
                Text = "CONSOLE OUTPUT",
                ForeColor = TextMuted,
                Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold),
                Location = new Point(14, 12),
                AutoSize = true
            };

            _logBox = new RichTextBox
            {
                Location = new Point(12, 36),
                Size = new Size(logContainer.Width - 24, logContainer.Height - 48),
                BackColor = BgDark,
                ForeColor = TextPrimary,
                BorderStyle = BorderStyle.None,
                ReadOnly = true,
                Font = new Font("Consolas", 9.2f),
                WordWrap = true
            };

            logContainer.Controls.Add(logHeader);
            logContainer.Controls.Add(_logBox);

            _mainPanel.Controls.Add(sidebar);
            _mainPanel.Controls.Add(logContainer);
            Controls.Add(_mainPanel);
        }

        private Button CreateActionButton(string text, Color bg, Point loc, Size size)
        {
            var btn = new Button
            {
                Text = text,
                Location = loc,
                Size = size,
                FlatStyle = FlatStyle.Flat,
                BackColor = bg,
                ForeColor = TextPrimary,
                Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                TabStop = false
            };
            btn.FlatAppearance.BorderSize = bg == BgInput ? 1 : 0;
            btn.FlatAppearance.BorderColor = BorderColor;
            btn.FlatAppearance.MouseOverBackColor = bg == AccentPrimary ? AccentHover : Color.FromArgb(44, 48, 66);
            return btn;
        }

        private void StartAuth()
        {
            string key = _keyBox.Text.Trim();
            if (string.IsNullOrEmpty(key))
            {
                _loginStatus.ForeColor = AccentOrange;
                _loginStatus.Text = "Please enter a license key.";
                return;
            }

            _loginBtn.Enabled = false;
            _keyBox.Enabled = false;
            _loginStatus.ForeColor = TextMuted;
            _loginStatus.Text = "Connecting to KeyAuth...";

            new Thread(() =>
            {
                string sessionId;
                string err;
                if (!Program.KeyAuthInit(out sessionId, out err))
                {
                    SetLoginError("Init failed: " + err);
                    return;
                }

                string hwid = WindowsIdentity.GetCurrent().User.Value;
                if (!Program.KeyAuthLicense(sessionId, key, hwid, out err))
                {
                    Program.TryDeleteSavedKey();
                    SetLoginError("License rejected: " + err);
                    return;
                }

                Program.SaveKey(key);

                string extractErr;
                if (!Program.ExtractEmbeddedPayload(out extractErr))
                {
                    SetLoginError("Payload error: " + extractErr);
                    return;
                }

                BeginInvoke((Action)(() =>
                {
                    _loginPanel.Visible = false;
                    _mainPanel.Visible = true;
                    AppendLog("[auth] License verified. Runtime ready.", AccentGreen);
                    AppendLog("[info] Select a module on the left to begin.", TextMuted);
                }));
            }) { IsBackground = true }.Start();
        }

        private void SetLoginError(string msg)
        {
            BeginInvoke((Action)(() =>
            {
                _loginStatus.ForeColor = AccentOrange;
                _loginStatus.Text = msg;
                _loginBtn.Enabled = true;
                _keyBox.Enabled = true;
            }));
        }

        private void RunTask(string name, Action work)
        {
            if (_busy) return;
            _busy = true;
            SetButtonsEnabled(false);
            _logBox.Clear();
            AppendLog("=== " + name + " ===", AccentPrimary);

            new Thread(() =>
            {
                try
                {
                    work();
                }
                catch (Exception ex)
                {
                    AppendLog("[error] " + ex.Message, AccentOrange);
                }
                finally
                {
                    BeginInvoke((Action)(() =>
                    {
                        _busy = false;
                        SetButtonsEnabled(true);
                    }));
                }
            }) { IsBackground = true }.Start();
        }

        private void SetButtonsEnabled(bool enabled)
        {
            _btnInject.Enabled = enabled;
            _btnCheck.Enabled = enabled;
            _btnSpoof.Enabled = enabled;
            _btnClean.Enabled = enabled;
        }

        private void AppendLog(string line, Color? color = null)
        {
            if (InvokeRequired)
            {
                BeginInvoke((Action)(() => AppendLog(line, color)));
                return;
            }

            Color c = color ?? TextPrimary;
            if (color == null)
            {
                if (line.Contains("[OK]") || line.Contains("PASS") || line.Contains("SPOOF_ACTIVE") || line.Contains("Finished"))
                    c = AccentGreen;
                else if (line.Contains("[WARN]") || line.Contains("[MISS]") || line.Contains("FAIL") || line.Contains("[ERROR]") || line.Contains("failed"))
                    c = AccentOrange;
            }

            _logBox.SelectionStart = _logBox.TextLength;
            _logBox.SelectionLength = 0;
            _logBox.SelectionColor = c;
            _logBox.AppendText(line + Environment.NewLine);
            _logBox.ScrollToCaret();
        }

        // ============================================================
        // Module 1: Inject
        // ============================================================

        private void RunInjection()
        {
            File.WriteAllText(Program.LogPath, string.Empty);
            LogFileAndUi("loader", "ROB RUN internal loader");

            string cleanScript = Path.Combine(Program.BanfixDir, "clean_traces.ps1");
            if (File.Exists(cleanScript)) RunPowerShellFile(cleanScript, silent: true);

            if (!File.Exists(Program.DllPath))
            {
                LogFileAndUi("loader", "RobRunInternal.dll is missing.");
                return;
            }

            string mapperPath = Path.Combine(Program.ToolsDir, "orelia-mapper.exe");
            string driverPath = Path.Combine(Program.ToolsDir, "orelia-ioctl.sys");
            string injectorPath = Path.Combine(Program.ToolsDir, "ioctl-injector.exe");

            foreach (string req in new[] { mapperPath, driverPath, injectorPath })
            {
                if (!File.Exists(req))
                {
                    LogFileAndUi("loader", "Missing tool: " + req);
                    return;
                }
            }

            if (Process.GetProcessesByName("ROB RUN").Length == 0)
            {
                LogFileAndUi("loader", "ROB RUN.exe is not running. Start the game and wait for the lobby.");
                return;
            }

            LogFileAndUi("loader", "Keep ROB RUN focused. Do not click the game until this finishes.");

            bool mapped = false;
            for (int attempt = 1; attempt <= 3; attempt++)
            {
                if (RunCheckedTool("mapper", mapperPath, "\"" + driverPath + "\"", "Successfully mapped module on isolated core", null))
                {
                    mapped = true;
                    break;
                }

                if (attempt >= 3)
                {
                    LogFileAndUi("loader", "Mapper failed 3x. Reboot the PC and try again.");
                    return;
                }

                LogFileAndUi("loader", "Mapper failed. Retry " + attempt + " of 3 in 3 seconds...");
                Thread.Sleep(3000);
            }

            if (!mapped) return;

            string focusScript = Path.Combine(Program.BanfixDir, "focus_game.ps1");
            if (File.Exists(focusScript)) RunPowerShellFile(focusScript, silent: true);

            bool injected = RunCheckedTool(
                "injector",
                injectorPath,
                "\"" + Program.DllPath + "\"",
                "Successfully opened driver handle",
                "Successfully initialized module"
            );

            if (!injected)
            {
                LogFileAndUi("loader", "Injector failed. Keep the game focused and try again.");
                return;
            }

            LogFileAndUi("loader", "Finished. In game: INSERT opens the menu. ESP toggle: HOME.");
        }

        // ============================================================
        // Module 2: Preflight Check
        // ============================================================

        private void RunPreflightCheck()
        {
            var sb = new StringBuilder();
            bool fail = false;

            sb.AppendLine("ROB RUN KIT - PREFLIGHT REPORT");
            sb.AppendLine("Date: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Computer: " + Environment.MachineName);
            sb.AppendLine();
            sb.AppendLine("[OK]   Administrator.");

            string[] requiredFiles = new[]
            {
                "RobRunInternal.dll",
                @"tools\orelia-mapper.exe",
                @"tools\orelia-ioctl.sys",
                @"tools\ioctl-injector.exe",
                @"tools\msvcp140.dll",
                @"tools\vcruntime140.dll",
                @"tools\vcruntime140_1.dll",
                @"banfix\clean_traces.ps1",
                @"banfix\focus_game.ps1"
            };

            foreach (string rel in requiredFiles)
            {
                string full = Path.Combine(Program.RootDir, rel);
                if (File.Exists(full))
                {
                    sb.AppendLine("[OK]   " + rel + " (" + new FileInfo(full).Length + " bytes)");
                }
                else
                {
                    sb.AppendLine("[MISS] " + rel);
                    fail = true;
                }
            }

            sb.AppendLine(Process.GetProcessesByName("ROB RUN").Length > 0
                ? "[OK]   ROB RUN.exe is running."
                : "[WARN] ROB RUN.exe is not running. Start the game first.");

            int hvci = Program.ReadRegistryDword(
                @"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity",
                "Enabled"
            );
            sb.AppendLine(hvci == 1
                ? "[WARN] Memory Integrity (HVCI) is ON - turn it off and reboot."
                : "[OK]   Memory Integrity (HVCI) off or absent.");

            int blocklist = Program.ReadRegistryDword(
                @"SYSTEM\CurrentControlSet\Control\CI\Config",
                "VulnerableDriverBlocklistEnable"
            );
            sb.AppendLine(blocklist == 1
                ? "[WARN] Vulnerable Driver Blocklist is ON - turn it off and reboot."
                : "[OK]   Vulnerable Driver Blocklist off or absent.");

            sb.AppendLine();
            sb.AppendLine(fail
                ? "RESULT: FAIL - files or privileges are missing."
                : "RESULT: PASS - ready to inject.");

            string report = sb.ToString();
            File.WriteAllText(Program.ReportPath, report);
            foreach (string line in report.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None))
            {
                AppendLog(line);
            }
        }

        // ============================================================
        // Module 3: Spoof
        // ============================================================

        private void RunSpoof()
        {
            string mapperPath = Path.Combine(Program.ToolsDir, "orelia-mapper.exe");
            string spoofDir = Path.Combine(Program.BanfixDir, "spoof");
            string rrspoofExe = Path.Combine(spoofDir, "rrspoof.exe");
            string rrspoofSys = Path.Combine(spoofDir, "rrspoof.sys");
            string rrspoofRunSys = Path.Combine(spoofDir, "rrspoof_run.sys");

            if (!File.Exists(mapperPath) || !File.Exists(rrspoofExe))
            {
                AppendLog("[ERROR] Spoof files missing from runtime.", AccentOrange);
                return;
            }

            AppendLog("[0/7] Cleaning old traces...");
            string cleanTraces = Path.Combine(Program.BanfixDir, "clean_traces.ps1");
            if (File.Exists(cleanTraces)) RunPowerShellFile(cleanTraces, silent: true);

            AppendLog("[1/7] EAC clean...");
            string cleanEac = Path.Combine(Program.BanfixDir, "clean_eac.ps1");
            if (File.Exists(cleanEac)) RunPowerShellFile(cleanEac, silent: false);

            AppendLog("[2/7] Generating profile...");
            if (RunStreamedProcess(rrspoofExe, "--new \"" + rrspoofSys + "\" \"" + rrspoofRunSys + "\"") != 0)
            {
                AppendLog("BANFIX_FAIL", AccentOrange);
                return;
            }

            AppendLog("[3/7] Applying registry...");
            if (RunStreamedProcess(rrspoofExe, "--apply-reg \"" + rrspoofRunSys + "\"") != 0)
            {
                AppendLog("BANFIX_FAIL", AccentOrange);
                return;
            }

            AppendLog("[4/7] Restarting physical network adapters...");
            RunStreamedProcess(
                "powershell.exe",
                "-NoProfile -Command \"Get-NetAdapter -Physical | ForEach-Object { Write-Host ('restart ' + $_.Name); Restart-NetAdapter -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue }\""
            );

            AppendLog("[5/7] Mapping spoofer...");
            if (RunStreamedProcess(mapperPath, "\"" + rrspoofRunSys + "\"") != 0)
            {
                AppendLog("BANFIX_FAIL", AccentOrange);
                return;
            }

            AppendLog("[6/7] Verifying...");
            RunStreamedProcess(rrspoofExe, "--check");

            AppendLog("SPOOF_ACTIVE - launch ROB RUN from Steam now.", AccentGreen);
        }

        // ============================================================
        // Module 4: Clean
        // ============================================================

        private void RunClean()
        {
            string cleanScript = Path.Combine(Program.BanfixDir, "clean_traces.ps1");
            if (!File.Exists(cleanScript))
            {
                AppendLog("[ERROR] clean_traces.ps1 is missing.", AccentOrange);
                return;
            }

            RunPowerShellFile(cleanScript, silent: false);
            AppendLog("Done. Traces and logs cleaned.", AccentGreen);
        }

        // ============================================================
        // Process Helpers
        // ============================================================

        private bool RunCheckedTool(string tag, string exePath, string args, string check1, string check2)
        {
            LogFileAndUi(tag, "Running " + Path.GetFileName(exePath));

            var psi = new ProcessStartInfo
            {
                FileName = exePath,
                Arguments = args,
                WorkingDirectory = Program.RootDir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            string output;
            int exitCode;
            using (var proc = Process.Start(psi))
            {
                string stdout = proc.StandardOutput.ReadToEnd();
                string stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit();
                exitCode = proc.ExitCode;
                output = stdout + stderr;
            }

            if (!string.IsNullOrEmpty(output))
            {
                File.AppendAllText(Program.LogPath, output);
                foreach (string line in output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    AppendLog(line);
                }
            }

            bool ok = !string.IsNullOrEmpty(output) && output.Contains(check1);
            if (ok && !string.IsNullOrEmpty(check2))
            {
                ok = output.Contains(check2);
            }

            LogFileAndUi(tag, "Exit code " + exitCode + " ok=" + (ok ? "1" : "0"));
            return ok;
        }

        private int RunStreamedProcess(string exePath, string args)
        {
            var psi = new ProcessStartInfo
            {
                FileName = exePath,
                Arguments = args,
                WorkingDirectory = Program.RootDir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using (var proc = new Process { StartInfo = psi })
            {
                proc.OutputDataReceived += (s, e) => { if (e.Data != null) AppendLog(e.Data); };
                proc.ErrorDataReceived += (s, e) => { if (e.Data != null) AppendLog(e.Data, AccentOrange); };
                proc.Start();
                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();
                proc.WaitForExit();
                return proc.ExitCode;
            }
        }

        private int RunPowerShellFile(string scriptPath, bool silent)
        {
            try
            {
                if (silent)
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" + scriptPath + "\"",
                        WorkingDirectory = Program.RootDir,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    };
                    using (var proc = Process.Start(psi))
                    {
                        proc.WaitForExit();
                        return proc.ExitCode;
                    }
                }
                return RunStreamedProcess("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -File \"" + scriptPath + "\"");
            }
            catch
            {
                return -1;
            }
        }

        private void LogFileAndUi(string tag, string message)
        {
            string line = "[" + tag + "] " + message;
            AppendLog(line);
            try
            {
                File.AppendAllText(Program.LogPath, line + Environment.NewLine);
            }
            catch { }
        }
    }
}
