# Remove filesystem artifacts written by earlier builds of the internal module.
# The shipped build has every file writer compiled out; this clears what the
# old builds left in %LOCALAPPDATA% and in the title's working directory.

$ErrorActionPreference = 'SilentlyContinue'

$logDir = Join-Path $env:LOCALAPPDATA 'RobRunInternal'
if (Test-Path -LiteralPath $logDir) {
    Remove-Item -LiteralPath $logDir -Recurse -Force
}

$gameDir = 'C:\Program Files (x86)\Steam\steamapps\common\Rob Run'
$names = @(
    'robrun_runtime.txt',
    'robrun_sweep.log',
    'rig-mapping.log',
    'rig-name-mismatches.log',
    'chamtrace.csv',
    'crash.log',
    'map_trace.log',
    'classscan.log',
    'nodescan.log'
)
if (Test-Path -LiteralPath $gameDir) {
    foreach ($name in $names) {
        $path = Join-Path $gameDir $name
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Force
        }
    }
}

Get-ChildItem -LiteralPath $env:TEMP -Filter 'rr-*.log' | Remove-Item -Force

# The injector's own transcript in the project root.
$root = Split-Path -Parent $PSScriptRoot
$runLog = Join-Path $root 'inject-run.log'
if (Test-Path -LiteralPath $runLog) {
    Remove-Item -LiteralPath $runLog -Force
}

Write-Output 'TRACES_CLEAN'
