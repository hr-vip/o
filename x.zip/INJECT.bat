@echo off
setlocal EnableExtensions
title ROB RUN - INJECT
cd /d "%~dp0"
mode con: cols=110 lines=45 >nul 2>&1

set "ROOT=%~dp0"
set "TOOLS=%ROOT%tools"
set "DLL=%ROOT%RobRunInternal.dll"
set "LOG=%ROOT%inject-run.log"

echo.>"%LOG%"
call :say loader "ROB RUN internal loader"
call :say loader "Folder: %ROOT%"

fltmc >nul 2>&1
if errorlevel 1 (
    call :say loader "NOT ADMINISTRATOR. Right-click INJECT.bat and choose Run as administrator."
    set "RC=1"
    goto :bye
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%banfix\clean_traces.ps1" >nul 2>&1

if not exist "%DLL%" (
    call :say loader "RobRunInternal.dll is missing from this folder."
    set "RC=2"
    goto :bye
)

for %%F in ("%TOOLS%\orelia-mapper.exe" "%TOOLS%\orelia-ioctl.sys" "%TOOLS%\ioctl-injector.exe") do (
    if not exist "%%~F" (
        call :say loader "Missing tool: %%~F"
        set "RC=3"
        goto :bye
    )
)

if not exist "%TOOLS%\msvcp140.dll" call :say loader "Warning: tools\msvcp140.dll missing; install the VC++ 2015-2022 x64 runtime if the injector will not start."

tasklist /fi "IMAGENAME eq ROB RUN.exe" | findstr /i "ROB RUN.exe" >nul
if errorlevel 1 (
    call :say loader "ROB RUN.exe is not running. Start the game and wait for the lobby."
    set "RC=4"
    goto :bye
)

call :say loader "DLL: %DLL%"
call :say loader "Keep ROB RUN focused. Do not click the game until this finishes."

set "MAP_TRIES=0"
:map_loop
set /a MAP_TRIES+=1
call :run mapper "%TOOLS%\orelia-mapper.exe" "%TOOLS%\orelia-ioctl.sys" "Successfully mapped module on isolated core"
if "%RUN_OK%"=="1" goto :mapped
if %MAP_TRIES% GEQ 3 (
    call :say loader "Mapper failed 3x. Reboot the PC and try again. Full log: %LOG%"
    set "RC=5"
    goto :bye
)
call :say loader "Mapper failed. Retry %MAP_TRIES% of 3 in 3 seconds..."
ping -n 4 127.0.0.1 >nul
goto :map_loop

:mapped
if exist "%ROOT%banfix\focus_game.ps1" powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%banfix\focus_game.ps1" >nul 2>&1
call :run injector "%TOOLS%\ioctl-injector.exe" "%DLL%" "Successfully opened driver handle" "Successfully initialized module"
if not "%RUN_OK%"=="1" (
    call :say loader "Injector failed. Keep the game focused and run INJECT.bat again. Full log: %LOG%"
    set "RC=6"
    goto :bye
)

call :say loader "Finished. In game: INSERT opens the menu. ESP toggle: HOME."
set "RC=0"
goto :bye

:say
echo [%1] %~2
echo [%1] %~2 >>"%LOG%"
exit /b 0

:run
call :say %1 "Running %~2"
set "TOUT=%TEMP%\rr-%1-%RANDOM%.log"
set "RUN_OK=0"
"%~2" "%~3" <nul >"%TOUT%" 2>&1
set "RC=%ERRORLEVEL%"
findstr /C:"%~4" "%TOUT%" >nul
if not errorlevel 1 set "RUN_OK=1"
if not "%~5"=="" (
    findstr /C:"%~5" "%TOUT%" >nul
    if errorlevel 1 set "RUN_OK=0"
)
type "%TOUT%"
type "%TOUT%" >>"%LOG%"
del "%TOUT%" >nul 2>&1
call :say %1 "Exit code %RC% ok=%RUN_OK%"
exit /b %RC%

:bye
echo.
echo Press any key to close this window.
pause
exit /b %RC%
