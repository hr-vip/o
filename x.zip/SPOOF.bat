@echo off
setlocal EnableExtensions
title ROB RUN - BAN FIX / HWID SPOOF
cd /d "%~dp0"

fltmc >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Run as administrator.
    pause
    exit /b 1
)

set "MAPPER=%~dp0tools\orelia-mapper.exe"
set "SPOOF=%~dp0banfix\spoof"
if not exist "%MAPPER%" (
    echo [ERROR] tools\orelia-mapper.exe is missing.
    pause
    exit /b 1
)
if not exist "%SPOOF%\rrspoof.exe" (
    echo [ERROR] banfix\spoof\rrspoof.exe is missing.
    pause
    exit /b 1
)

echo [0/7] old traces
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0banfix\clean_traces.ps1" >nul 2>&1

echo.
echo [1/7] EAC clean
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0banfix\clean_eac.ps1"
if errorlevel 1 echo [warn] cleaner returned a non-zero code

echo.
echo [2/7] profile
"%SPOOF%\rrspoof.exe" --new "%SPOOF%\rrspoof.sys" "%SPOOF%\rrspoof_run.sys"
if errorlevel 1 goto fail

echo.
echo [3/7] registry
"%SPOOF%\rrspoof.exe" --apply-reg "%SPOOF%\rrspoof_run.sys"
if errorlevel 1 goto fail

echo.
echo [4/7] adapters
powershell -NoProfile -Command "Get-NetAdapter -Physical | ForEach-Object { Write-Host ('restart ' + $_.Name); Restart-NetAdapter -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue }"

echo.
echo [5/7] map spoofer
"%MAPPER%" "%SPOOF%\rrspoof_run.sys" <nul
if errorlevel 1 goto fail

echo.
echo [6/7] verify
"%SPOOF%\rrspoof.exe" --check

echo.
echo SPOOF_ACTIVE - launch ROB RUN from Steam now.
echo After every reboot run SPOOF.bat again (or only step 3) before the game.
echo Press any key to close this window.
pause
exit /b 0

:fail
echo.
echo BANFIX_FAIL
pause
exit /b 1
