@echo off
setlocal EnableExtensions
title ROB RUN - CLEAN TRACES
cd /d "%~dp0"

fltmc >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Run as administrator.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0banfix\clean_traces.ps1"
echo.
echo Done. inject-run.log is removed with the rest.
pause
exit /b 0
